import java.lang.reflect.Array;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.*;

import com.sun.org.apache.bcel.internal.generic.RETURN;
import entities.Response;
import entities.Role;
import entities.User;

import javax.xml.bind.DatatypeConverter;
import java.util.function.Predicate;

import java.util.concurrent.TimeUnit;

public class API {

    public void showUsersAndTreirRoles(String fname) {
        System.out.println(fname);
        for (User u : users) {
            System.out.println(u.getName());
            for(Role r : u.getRoles()) {
                System.out.println(r.getName());
            }
        }
    }

    public void showRoles(String fname) {
        System.out.println(fname);
        for (Role r : roles) {
            System.out.println(r.getName());
        }
    }

    ArrayList<User> users = new ArrayList();
    ArrayList<Role> roles = new ArrayList();

    class AuthDetails {
        private String username;
        private String token;
        private Long expiration;

        public AuthDetails(String username, String token, Long expiration) {
            this.username = username;
            this.token = token;
            this.expiration = expiration;
        }

        public String getToken() {
            return this.token;
        }

        public Long getTokenExpiration() {
            return this.expiration;
        }

        public String getUsername() {
            return this.username;
        }
    }

    ArrayList<AuthDetails> authDetails = new ArrayList<AuthDetails>();


    public static void main(String[] args) {
        System.out.println("Test assignment");
    }

    public Response createUser(String name, String pass) {

        List usernames = new ArrayList();

        for (User u : users) {
            usernames.add(u.getName());
        }

        if (usernames.contains(name)) {
            return new Response(422, String.format("user %s already exists", name));
        } else {
            if (!name.equals("")) {
                User newUser = new User(name, pass);
                users.add(newUser);
                showUsersAndTreirRoles("createUser");
                return new Response(200, String.format("user %s created", name));
            } else return new Response(422, String.format("user name is empty"));

        }

    }


    public Response deleteUser(User user) {
        showUsersAndTreirRoles("deleteUser");

        List usernames = new ArrayList();
        for (User u : users) {
            usernames.add(u.getName());
        }

        if (!usernames.contains(user.getName())) {
            return new Response(422, String.format("user %s does not exists", user.getName()));
        } else {
            users.remove(user);
            return new Response(200, String.format("user %s has been deleted", user.getName()));
        }
    }


    public Response createRole(String roleName) {

        List roleNames = new ArrayList();

        for (Role r : roles) {
            roleNames.add(r.getName());
        }

        if (roleNames.contains(roleName)) {
            return new Response(422, String.format("role %s already exists", roleName));
        } else {
            Role newRole = new Role(roleName);
            roles.add(newRole);
            showRoles("createRole");
            return new Response(200, String.format("role %s created", roleName));
        }
    }

    public Response deleteRole(Role role) {
        showRoles("deleteRole");
        ArrayList<String> roleNames = new ArrayList();
        for (Role r : roles) {
            roleNames.add(r.getName());
        }
        System.out.println("roleNames: " + roleNames);
        if (!roleNames.contains(role.getName())) {
            return new Response(422, String.format("role %s does not exists", role.getName()));
        } else {
            roles.remove(role);
            return new Response(200, String.format("role %s has been deleted", role.getName()));
        }
    }

    public Response addRoleToUser(User user, Role role) {

        for (User u : users) {
            if (u.getName().equals(user.getName())) {
                if (u.getRoles().contains(role.getName())) {
                    return new Response(422, String.format("role %s for user %s already exists",
                            role.getName(), user.getName()));
                } else {
                    u.addRole(role);
                }
            }
        }

        showUsersAndTreirRoles("addRoleToUser");
        return new Response(200, String.format("role %s has been added", role.getName()));
    }

    private String createToken(String username, Long curtime) {

        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("MD5");
            md.update(username.getBytes());
            md.update(curtime.toString().getBytes());
        }
        catch (NoSuchAlgorithmException e) {
            System.err.println("MD5 is not a valid message digest algorithm");
        }

        byte[] digest = md.digest();
        String myHash = DatatypeConverter
                .printHexBinary(digest).toUpperCase();
        return myHash;

    }

    public Response authenticate(String username, String password) {

        User userFound = null;
        for (User u : users) {
            if (u.getName().equals(username)) {
                userFound = u;
            }
        }

        if (userFound != null) {

            String thisUserPass = userFound.hashPassword(password);

            System.out.println("existing user pass: " + userFound.getPass());
            System.out.println("thisUserPass: " + thisUserPass);

            if (thisUserPass.equals(userFound.getPass())) {

                Long curtime = System.currentTimeMillis();

                String newToken = createToken(username, curtime);

                API.AuthDetails newTokenTuple = new API.AuthDetails(username, newToken, curtime);
                authDetails.add(newTokenTuple);
                for (AuthDetails a : authDetails) {
                    System.out.println(a);
                }
                return new Response(200, newToken);
            } else
                return new Response(422, String.format("password for %s is not correct", username));

        } else
            return new Response(422, String.format("username %s not found", username));


    }

    public void invalidate(final String token) {
        AuthDetails currentAuthDetails = null;
        List authDetailsTokens = new ArrayList();
        System.out.println(authDetails);
        for (AuthDetails a : authDetails) {
            System.out.println(a.getToken());
            authDetailsTokens.add(a.getToken());

            if (a.getToken().equals(token)) {
                currentAuthDetails = a;
            }
        }

        if (currentAuthDetails != null) {
            authDetails.remove(currentAuthDetails);
        }

        System.out.println("after");
        for (AuthDetails a : authDetails) {
            System.out.println(a.getToken());
        }

    }

    public Boolean checkRole(String token, Role role) {
        //authDetails
        //users

        Long curtime = System.currentTimeMillis();

        AuthDetails authDetail = null;

        for (AuthDetails a : authDetails) {
            if (a.getToken().equals(token))
                authDetail = a;
        }

        String username = "";
        Long tokenTime = 0L;
        if (authDetail != null) {
            username = authDetail.getUsername();
            tokenTime = authDetail.getTokenExpiration();
        }

        Long tokenLifeHours = TimeUnit.MILLISECONDS.toHours(curtime - tokenTime);
        Long tokenLifeSeconds = TimeUnit.MILLISECONDS.toSeconds(curtime - tokenTime);

        System.out.println("tokenTime: " + tokenTime + "tokenLifeSeconds: " + tokenLifeSeconds);

        if (tokenLifeSeconds < 2 ) {
            System.out.println("here");
            List usernames = new ArrayList();
            for (User u : users) {
                usernames.add(u.getName());
                System.out.println(u.getName());
            }

            System.out.println("username: " + username);
            HashSet<Role> userRoles = new HashSet<>();
            if (usernames.contains(username)) {
                System.out.println("here2");
                for (User u : users) {
                    if (u.getName().equals(username)) {
                        userRoles = u.getRoles();
                    }
                }
                System.out.println("printing roles");
                ArrayList<String> userRoleNames = new ArrayList();
                for( Role r : userRoles) {
                    userRoleNames.add(r.getName());
                }

                if (userRoleNames.contains(role.getName())) {
                    return true;
                } else {
                    return false;
                }

            } else return false;



        } else {
            System.out.println("token expired");
            return false;
        }

    }

    public Optional<HashSet<Role>> allRoles(String token) {
        AuthDetails authDetail = null;

        for (AuthDetails a : authDetails) {
            if (a.getToken().equals(token))
                authDetail = a;
        }

        String username = "";
        if (authDetail != null) {
            username = authDetail.getUsername();
        } else {
            return Optional.empty();
        }

        List usernames = new ArrayList();
        for (User u : users) {
            usernames.add(u.getName());
        }


        HashSet<Role> userRoles = new HashSet<>();
        if (usernames.contains(username)) {
            for (User u : users) {
                userRoles = u.getRoles();
            }
            return Optional.of(userRoles);
        } else return Optional.empty();

    }











}
